"""占位 lzfse: pymobiledevice3 依赖 pyimg4 -> lzfse, Windows + Python 3.13 没有编译好的包, 且需要 C++ 编译器。
推文件进应用 (apps push) 用不到 LZFSE 压缩, 这里只让依赖满足; 真调用会报错。"""


def _no(*a, **k):
    raise NotImplementedError("lzfse 是占位包 (tools/ios_win/lzfse-0.4.2-py3-none-any.whl), 没有压缩实现")


compress = decompress = _no
